ups-adaptor Rev A -- JLCPCB order package
=========================================

Upload these three, in this order:

  PCB tab         ups-adaptor-gerbers.zip     (upload the ZIP as-is)
  Assembly, BOM   bom.csv
  Assembly, CPL   cpl.csv

Board settings: JLCPCB's defaults are correct for this board -- 2 layer,
1.6 mm FR-4, 1 oz copper, HASL, green with white silkscreen, tented vias.
Tented matters: U1's thermal vias have no back mask opening and the back
silkscreen artwork prints over them.

Change from the defaults:
  * Quantity 10, not 5.
  * Turn on PCB Assembly, ASSEMBLY SIDE: TOP ONLY. This board cannot be
    double-sided -- Economic PCBA is single-sided placement, and Standard
    PCBA's minimum board is 70x70 mm against this one's 36x58.
  * J3 and J5 are through-hole and are NOT in the CPL. Either fit them
    yourself or re-run tools/pack-fab.sh --with-tht.
  * JLC prints their order number somewhere of their choosing. The back of
    this board is artwork; either pay to remove the number or accept it.

BEFORE PAYING, open Component Placements and check these against the board.
The CPL carries seven rotations that are NOT KiCad's own angle, each one
decided by looking at this preview, and they are the failure nobody can see
after assembly:

  U2 SOIC-16   0     body runs EAST-WEST, 8 pads north and 8 south
  U3 SOT-223   180   3 leads WEST, tab EAST
  U4 SOT-23-5  270   3 leads WEST, 2 EAST
  D1 SOT-23-6  270   3 leads WEST, 3 EAST
  D2 SOT-23-6  270   3 leads WEST, 3 EAST
  Q1 SOT-23    180   2 leads WEST, 1 EAST
  Q2 SOT-23    270   2 leads SOUTH, 1 NORTH

U4, D1 and D2 were inferred from an earlier preview rather than confirmed,
so they are the ones worth the extra ten seconds.

J1 (USB-C) and U1 take KiCad's own angle. Both were tested: the community
rotation table has a rule for J1's exact part number and it drew the
connector UPSIDE DOWN, which is why this project no longer applies that
table at all.

Positions are pad CENTROIDS, not KiCad anchors. U1, J1 and J2 differ by
3.77, 1.46 and 2.49 mm between the two, and at 3.77 mm every one of the
module's 40 castellated pads misses.

Polarity on silk: a dot marks pin 1. D3 and D4 instead carry a BAR across
the CATHODE end -- on a diode a dot would read as the capacitor convention
and mean the opposite.
